

# Linux System Health & Log Monitoring Tool 

## Features 

 - Disk usage monitoring 
 - Memory usage tracking 
 - CPU load check 
 - SSH failed login detection 

## Technolgies 
 - Linux
 - Bash 
 - Git 

## Usage 
```bash 
./health_check.sh 
sudo ./ssh_failed_logins.sh

